public interface LaysEggsBehavior {
    public abstract void laysEgg( );
}