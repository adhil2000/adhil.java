public class LaysEggsBroody implements LaysEggsBehavior{
    public void laysEgg( ) {
        System.out.println("Lays eggs, but will fight you for them.");
    }
}
