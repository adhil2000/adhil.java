public class LaysToysEggs implements LaysEggsBehavior{
    public void laysEgg( ) {
        System.out.println("Lays toy eggs.");
    }
}
