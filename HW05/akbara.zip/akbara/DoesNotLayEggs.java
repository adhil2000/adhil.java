public class DoesNotLayEggs implements LaysEggsBehavior{
    public void laysEgg( ) {
        System.out.println("Not an egg layer.");
    }
}
