public class LaysEggsNotBroody implements LaysEggsBehavior{
    public void laysEgg( ) {
        System.out.println("Lays eggs and will give them up if fed.");
    }
}
