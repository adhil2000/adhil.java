public class Derived extends Base {

   public void f3( ) {
      System.out.println("Derived::f3");
   }

   public void f4(){
      System.out.println("Derived::foo2");
      System.out.println("Derived::f2");
   }
   public void f5( ) {
      System.out.println("Derived::f5");
   }

   public void f6( ) {
      System.out.println("Derived::f6");
   }
   
   private void f1( ) {
      System.out.println("Derived::f1");
   }
}
