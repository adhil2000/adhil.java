public class Turnoff extends Command{
    public void executeCommand(int s) {
        System.out.println("Turning off the TV");
    }
}
