public class Turndown extends Command {
    public void executeCommand(int s) {
        System.out.println("Volume turned down to " + --x);
    }
}
