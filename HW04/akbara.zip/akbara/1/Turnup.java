public class Turnup extends Command{
    public void executeCommand(int s) {
        System.out.println("Volume turned up to " + ++x);
    }
}
