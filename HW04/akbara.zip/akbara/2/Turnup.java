public class Turnup extends Turndown{
    public void executeCommand(int s) {
        System.out.println("Volume turned up to " + ++x);
    }
}
