public interface Command {
    public void executeCommand(int s);
}

