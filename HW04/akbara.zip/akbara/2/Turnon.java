public class Turnon implements Command{
    public void executeCommand(int s) {
        System.out.println("Turning on the TV");
    }
}
