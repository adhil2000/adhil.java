package game;

public interface MovementObserver {

    abstract void observerUpdate(int moves);
}
