package game;

public interface MovementSubject {

    void registerMovementObserver(MovementObserver observer);
}
