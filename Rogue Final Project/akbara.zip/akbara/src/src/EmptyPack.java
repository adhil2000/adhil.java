package src;

public class EmptyPack extends CreatureAction {

    public EmptyPack(String _name, Creature _owner) {
        super(_owner);
    }

    @Override
    public void initialize(ObjectDisplayGrid object) {
        // Hmmm...
    }
}
